import { json } from '@remix-run/node';
import { useLoaderData, useFetcher } from '@remix-run/react';
import { authenticate } from '../shopify.server.js';
import db from "../db.server.js";

import {
  IndexTable,
  ButtonGroup,
  Button,
  Modal,
  TextField,
  Thumbnail,
  Page
} from '@shopify/polaris';
import { useState, useCallback } from 'react';

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);

  const response = await admin.graphql(`
    query {
      products(first: 250) {
        edges {
          node {
            id
            title
            handle
            images(first: 1) {
              edges {
                node {
                  originalSrc
                  altText
                }
              }
            }
            variants(first: 1) {
              edges {
                node {
                  id
                  price
                }
              }
            }
          }
        }
      }
    }
  `);

  const body = await response.json();

  if (body.errors) {
    console.error("GraphQL errors:", body.errors);
    throw new Response("Failed to fetch products", { status: 500 });
  }

  const customer_data = await db.Custom_Field.findMany();

  const reviewMap = new Map(
    customer_data.map((item) => [item.product_id, item.review_snippet])
  );

  const products = body.data.products.edges.map(({ node }) => ({
    id: node.id,
    title: node.title,
    handle: node.handle,
    image: node.images?.edges[0]?.node?.originalSrc || null,
    price: node.variants?.edges[0]?.node?.price || '',
    variantId: node.variants?.edges[0]?.node?.id || '',
    review_snippet: reviewMap.get(node.id) || '',
  }));

  return json(products);

};


export const action = async ({ request }) => {
  const { admin } = await authenticate.admin(request);
  const body = await request.json();
  const { id, title, variantId, price, reviewSnipit } = body;

  const mutation = `
    mutation UpdateVariantPrice {
  productVariantsBulkUpdate(
    productId: "${id}",
    variants: [
      {
        id: "${variantId}",
        price: ${price}
      }
    ]
  ) {
    productVariants {
      id
      price
    }
    userErrors {
      field
      message
    }
  }
}
  `;

  const variables = {
    input: { id, title },
    variantInput: { id: variantId, price },
  };

  const response = await admin.graphql(mutation, { variables });
  const result = await response.json();


  // const savedConfig = await db.Custom_Field.create({
  //   data: {
  //     product_id: id,
  //     review_snippet: reviewSnipit
  //   },
  // });
const savedConfig = await db.Custom_Field.upsert({
  where: { product_id: id },
  update: {
    review_snippet: reviewSnipit,
    updatedAt: new Date(),
  },
  create: {
    product_id: id,
    review_snippet: reviewSnipit,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
});



  return json({ success: true });
};

export default function AdditionalPage() {
  const data = useLoaderData();
  const fetcher = useFetcher();
  const itemsPerPage = 10;

  const [currentPage, setCurrentPage] = useState(1);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedPrice, setEditedPrice] = useState('');
  const [reviewSnipit, setRivewSnipited] = useState('');

  const openModal = (product) => {
    setSelectedProduct(product);
    setEditedTitle(product.title);
    setEditedPrice(product.price);
    setRivewSnipited(product.review_snippet);
    setIsModalOpen(true);
  };

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  }, []);

  const handleSave = async () => {
    fetcher.submit(
      {
        id: selectedProduct.id,
        title: editedTitle,
        price: editedPrice,
        variantId: selectedProduct.variantId,
        reviewSnipit: reviewSnipit
      },
      {
        method: 'post',
        encType: 'application/json',
        action: '.',
      }
    );

    closeModal();
  };

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = data.slice(startIndex, endIndex);
  const totalPages = Math.ceil(data.length / itemsPerPage);

  const rowMarkup = currentItems.map(({ image, id, price, title, variantId, review_snippet }, index) => (
    <IndexTable.Row id={id} key={id} position={index}>
      <IndexTable.Cell>{image ? <img height="40px" src={image} alt="" /> : '—'}</IndexTable.Cell>
      <IndexTable.Cell>{price}</IndexTable.Cell>
      <IndexTable.Cell>{title}</IndexTable.Cell>
      <IndexTable.Cell>{review_snippet}</IndexTable.Cell>
      <IndexTable.Cell>
        <Button onClick={() => openModal({ id, image, title, price, variantId, review_snippet })}>Edit</Button>
      </IndexTable.Cell>
    </IndexTable.Row>
  ));

  return (
    <>
    <Page>
      <IndexTable
        itemCount={data.length}
        headings={[
          { title: 'Image' },
          { title: 'Price' },
          { title: 'Title' },
          { title: 'Review Snippet' },
          { title: 'Actions' },
        ]}
        selectable={false}
      >
        {rowMarkup}
      </IndexTable>

      <div className="polaris-btn" style={{ marginTop: '1rem' }}>
        <ButtonGroup segmented>
          <Button
            primary
            onClick={() => setCurrentPage((p) => p - 1)}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <span className="space-page">{currentPage}</span>
          <span>/</span>
          <span className="space-page">{totalPages}</span>
          <Button
            primary
            onClick={() => setCurrentPage((p) => p + 1)}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </ButtonGroup>
      </div>

      <Modal
        open={isModalOpen}
        onClose={closeModal}
        title="Edit Product"
        primaryAction={{ content: 'Save', onAction: handleSave }}
        secondaryActions={[{ content: 'Cancel', onAction: closeModal }]}
      >
        <Modal.Section>
          {selectedProduct && (
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
              {selectedProduct.image && (
                <Thumbnail source={selectedProduct.image} alt="Product" size="large" />
              )}
              <div style={{ flexGrow: 1 }}>
                <TextField
                  label="Title"
                  value={editedTitle}
                  onChange={setEditedTitle}
                  autoComplete="off"
                />
                <TextField
                  label="Price"
                  value={editedPrice}
                  onChange={setEditedPrice}
                  type="number"
                  autoComplete="off"
                />
                <TextField
                  label="ReviewSnipit"
                  value={reviewSnipit}
                  onChange={setRivewSnipited}
                  type="text"
                  autoComplete="off"
                />
              </div>
            </div>
          )}
        </Modal.Section>
      </Modal>
      </Page>
    </>
  );
}
