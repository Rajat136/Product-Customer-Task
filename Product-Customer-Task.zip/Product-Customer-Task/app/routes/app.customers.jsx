import { json } from '@remix-run/node';
import { useLoaderData, useFetcher } from '@remix-run/react';
import { useEffect } from 'react';
import { authenticate } from '../shopify.server.js';
import db from "../db.server.js";
import {
  IndexTable,
  Button,
  Modal,
  TextField,
  Page
} from '@shopify/polaris';
import { useState, useCallback } from 'react';
import crypto from 'crypto';

function validateHmac(query, secret) {
  const { hmac, ...params } = Object.fromEntries(query.entries());
  const message = new URLSearchParams(params).toString();
  const generatedHmac = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');
  return generatedHmac === hmac;
}

export const loader = async ({ request }) => {
  const url = new URL(request.url);
  const isAppProxy = url.pathname.includes('/apps/custom-fields');
  const { admin } = await authenticate.admin(request);

  if (isAppProxy) {
    const isValid = validateHmac(url.searchParams, process.env.SHOPIFY_API_SECRET);
    if (!isValid) return new Response('Unauthorized', { status: 401 });

    const customerId = url.searchParams.get('customerId');

    const response = await admin.graphql(`
      query {
        customer(id: "gid://shopify/Customer/${customerId}") {
          id
          firstName
          lastName
          email
          phone
          note
        }
      }
    `);

    const body = await response.json();
    const customer = body.data.customer;

    let noteData = {};
    try {
      noteData = customer.note ? JSON.parse(customer.note) : {};
    } catch {
      noteData = {};
    }

    return json({
      customerId: customer.id,
      first_name: customer.firstName,
      last_name: customer.lastName,
      email: customer.email,
      phone: customer.phone || '',
      points: noteData.points || '0',
      coupon_code: noteData.coupon_code || '',
      note: noteData.note || '',
    });
  }

  const response = await admin.graphql(`
    query {
      customers(first: 20) {
        edges {
          node {
            id
            firstName
            lastName
            email
            phone
            note
          }
        }
      }
    }
  `);

  const body = await response.json();

  if (body.errors) {
    console.error('GraphQL errors:', body.errors);
    throw new Response('Failed to fetch customers', { status: 500 });
  }
  const customer_data = await db.CustomField.findMany();

  const customFieldMap = new Map(customer_data.map(field => [field.customerId, field]));

  const customers = body.data.customers.edges.map(({ node }) => {
    const custom = customFieldMap.get(node.id);

    return {
      id: node.id,
      first_name: node.firstName,
      last_name: node.lastName,
      email: node.email,
      phone: node.phone || '',
      points: custom?.points?.toString() || '0',
      coupon_code: custom?.couponCode || '',
      note: node?.note || '',
    };
  });


  return json(customers);
};


export const action = async ({ request }) => {
  const { admin } = await authenticate.admin(request);
  const body = await request.json();

  const { id, first_name, last_name, email, phone, points, coupon_code, note } = body;

  if (phone) {
    const searchQuery = `
      query {
        customers(first: 1, query: "phone:${phone.trim()}") {
          edges {
            node {
              id
              email
              phone
            }
          }
        }
      }
    `;

    const phoneRes = await admin.graphql(searchQuery);
    const phoneData = await phoneRes.json();
    const foundCustomer = phoneData?.data?.customers?.edges?.[0]?.node;

    if (foundCustomer && foundCustomer.id !== id) {
      return json(
        {
          success: false,
          error: `Phone number already in use by another customer (${foundCustomer.email || "no email"})`,
        },
        { status: 400 }
      );
    }
  }


  const mutation = `
    mutation customerUpdate($input: CustomerInput!) {
      customerUpdate(input: $input) {
        customer {
          id
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const input = {
    id,
    firstName: first_name,
    lastName: last_name,
    email,
    phone,
    note,
  };

  const response = await admin.graphql(mutation, { variables: { input } });
  const result = await response.json();

  if (result.data.customerUpdate.userErrors.length > 0) {
    return json({ success: false, error: result.data.customerUpdate.userErrors[0].message }, { status: 400 });
  }

  await db.CustomField.upsert({
    where: { customerId: id },
    update: {
      points: parseInt(points),
      couponCode: coupon_code,
      note,
      updatedAt: new Date(),
    },
    create: {
      customerId: id,
      points: parseInt(points),
      couponCode: coupon_code,
      note,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  });

  return json({ success: true });
};


export default function AdminCustomers() {
  const data = useLoaderData();
  const fetcher = useFetcher();

  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editedFirstName, setEditedFirstName] = useState('');
  const [editedLastName, setEditedLastName] = useState('');
  const [editedEmail, setEditedEmail] = useState('');
  const [editedPhone, setEditedPhone] = useState('');
  const [editedPoints, setEditedPoints] = useState('');
  const [editedCoupon, setEditedCoupon] = useState('');
  const [editedNote, setEditedNote] = useState('');

  const openModal = (customer) => {
    setSelectedCustomer(customer);
    setEditedFirstName(customer.first_name);
    setEditedLastName(customer.last_name);
    setEditedEmail(customer.email);
    setEditedPhone(customer.phone);
    setEditedPoints(customer.points);
    setEditedCoupon(customer.coupon_code);
    setEditedNote(customer.note);
    setIsModalOpen(true);
  };

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedCustomer(null);
  }, []);

  useEffect(() => {
    if (fetcher.data?.success === false && fetcher.data?.error) {
      alert(fetcher.data.error);
    } else if (fetcher.data?.success) {
      alert("Customer updated successfully!");
      closeModal();
    }
  }, [fetcher.data]);

  const handleSave = async () => {
    fetcher.submit(
      {
        id: selectedCustomer.id,
        first_name: editedFirstName,
        last_name: editedLastName,
        email: editedEmail,
        phone: editedPhone,
        points: editedPoints,
        coupon_code: editedCoupon,
        note: editedNote,
      },
      {
        method: 'post',
        encType: 'application/json',
        action: '.',
      }
    );

    closeModal();
  };

  const rowMarkup = data.map((customer, index) => (
    <IndexTable.Row id={customer.id} key={customer.id} position={index}>
      <IndexTable.Cell>
        {customer.first_name} {customer.last_name}
      </IndexTable.Cell>
      <IndexTable.Cell>{customer.email}</IndexTable.Cell>
      <IndexTable.Cell>{customer.phone}</IndexTable.Cell>
      <IndexTable.Cell>{customer.points}</IndexTable.Cell>
      <IndexTable.Cell>{customer.coupon_code}</IndexTable.Cell>
      <IndexTable.Cell>{customer.note}</IndexTable.Cell>
      <IndexTable.Cell>
        <Button onClick={() => openModal(customer)}>Edit</Button>
      </IndexTable.Cell>
    </IndexTable.Row>
  ));

  return (
    <>
   <Page>
      <IndexTable
        itemCount={data.length}
        headings={[
          { title: 'Name' },
          { title: 'Email' },
          { title: 'Phone' },
          { title: 'Points' },
          { title: 'Coupon' },
          { title: 'Note' },
          { title: 'Actions' },
        ]}
        selectable={false}
      >
        {rowMarkup}
      </IndexTable>

      <Modal
        open={isModalOpen}
        onClose={closeModal}
        title="Edit Customer"
        primaryAction={{ content: 'Save', onAction: handleSave }}
        secondaryActions={[{ content: 'Cancel', onAction: closeModal }]}
      >
        <Modal.Section>
          {selectedCustomer && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <TextField
                label="First Name"
                value={editedFirstName}
                onChange={setEditedFirstName}
                autoComplete="off"
              />
              <TextField
                label="Last Name"
                value={editedLastName}
                onChange={setEditedLastName}
                autoComplete="off"
              />
              <TextField
                label="Email"
                value={editedEmail}
                onChange={setEditedEmail}
                autoComplete="off"
              />
              <TextField
                label="Phone"
                value={editedPhone}
                onChange={setEditedPhone}
                autoComplete="off"
              />
              <TextField
                label="Points"
                value={editedPoints}
                onChange={setEditedPoints}
                autoComplete="off"
              />
              <TextField
                label="Coupon Code"
                value={editedCoupon}
                onChange={setEditedCoupon}
                autoComplete="off"
              />
              <TextField
                label="Note"
                value={editedNote}
                onChange={setEditedNote}
                multiline
                autoComplete="off"
              />
            </div>
          )}
        </Modal.Section>
      </Modal>
     </Page>
    </>
  );
}