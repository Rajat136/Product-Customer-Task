import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  try {
    const { admin, session } = await authenticate.admin(request);
    
    if (!session) {
      return json({ 
        status: "error", 
        message: "No session found",
        timestamp: new Date().toISOString()
      }, { status: 401 });
    }

    if (!session.shop) {
      return json({ 
        status: "error", 
        message: "Shop name is null",
        sessionId: session.id,
        timestamp: new Date().toISOString()
      }, { status: 401 });
    }

    // Check if session is expired
    const isExpired = session.expires && new Date() > new Date(session.expires);
    
    return json({
      status: "success",
      shop: session.shop,
      sessionId: session.id,
      isExpired,
      expires: session.expires,
      scope: session.scope,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    return json({ 
      status: "error", 
      message: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
};
