
import { json } from "@remix-run/node";
import db  from '../db.server.js';

export async function loader({ request }) {
  const url = new URL(request.url);
  const customerid = url.searchParams.get("customerid");

  if (!customerid) {
    return json({ error: "Missing customerid" }, { status: 400 });
  }

  const data = await db.CustomField.findFirst({
    where: { customerId: `gid://shopify/Customer/${customerid}` },
  });

  return json({
    points: data?.points ?? 0,
    couponCode: data?.couponCode || "",
  });
}
