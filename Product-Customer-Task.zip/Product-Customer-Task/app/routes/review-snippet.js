import { json } from '@remix-run/node';
import db  from '../db.server.js';

export async function loader({ request }) {
  const url = new URL(request.url);
  const productId = url.searchParams.get("productId");
  const data = await db.custom_Field.findFirst({
    where: { product_id: "gid://shopify/Product/" + productId },
  });

  return json({ review_snippet: data?.review_snippet || "" });
}
 