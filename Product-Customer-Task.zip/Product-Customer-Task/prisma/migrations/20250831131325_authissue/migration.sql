/*
  Warnings:

  - You are about to alter the column `locale` on the `session` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `VarChar(10)`.
*/

-- AlterTable
ALTER TABLE `session` ADD COLUMN `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    ADD COLUMN `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    MODIFY `shop` VARCHAR(255) NOT NULL,
    MODIFY `state` VARCHAR(255) NOT NULL,
    MODIFY `scope` TEXT NULL,
    MODIFY `accessToken` TEXT NOT NULL,
    MODIFY `firstName` VARCHAR(255) NULL,
    MODIFY `lastName` VARCHAR(255) NULL,
    MODIFY `email` VARCHAR(255) NULL,
    MODIFY `locale` VARCHAR(10) NULL;

-- CreateIndex
CREATE INDEX `session_shop_idx` ON `session`(`shop`);

-- CreateIndex
CREATE INDEX `session_expires_idx` ON `session`(`expires`);
