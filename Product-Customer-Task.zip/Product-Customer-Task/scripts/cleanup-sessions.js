import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function cleanupExpiredSessions() {
  try {
    console.log("Starting session cleanup...");
    
    // Delete expired sessions
    const result = await prisma.session.deleteMany({
      where: {
        expires: {
          lt: new Date()
        }
      }
    });
    
    console.log(`Deleted ${result.count} expired sessions`);
    
    // Find sessions with null shop names
    const nullShopSessions = await prisma.session.findMany({
      where: {
        shop: null
      }
    });
    
    if (nullShopSessions.length > 0) {
      console.log(`Found ${nullShopSessions.length} sessions with null shop names`);
      
      // Delete sessions with null shop names
      const deleteResult = await prisma.session.deleteMany({
        where: {
          shop: null
        }
      });
      
      console.log(`Deleted ${deleteResult.count} sessions with null shop names`);
    }
    
    // Get total session count
    const totalSessions = await prisma.session.count();
    console.log(`Total sessions remaining: ${totalSessions}`);
    
  } catch (error) {
    console.error("Error during session cleanup:", error);
  } finally {
    await prisma.$disconnect();
  }
}

// Run cleanup if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  cleanupExpiredSessions();
}

export { cleanupExpiredSessions };
